
Python Externalized Runtime
===========================

This is the python runtime definition that will soon be used by gcloud for
generating dockerfiles for GAE.
